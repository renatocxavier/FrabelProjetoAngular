import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OmdbService } from '../../services/omdb.service';
import { FavoritesService } from '../../services/favorites.service';
import { Movie } from '../../models/movie';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './movie-search.component.html',
  styleUrls: ['./movie-search.component.css'],
})
export class MovieSearchComponent implements OnInit {
  searchQuery: string = '';
  movies: Movie[] = [];
  errorMessage: string = '';
  currentPage: number = 1;

  constructor(
    private omdbService: OmdbService,
    private favoritesService: FavoritesService,
    private router: Router // Adicionado o Router
  ) {}

  goToFavorites(): void {
    this.router.navigate(['/favorites']);
  }

  ngOnInit(): void {
    this.loadInitialMovies();
  }

  loadInitialMovies(): void {
    const defaultQuery = 'Marvel'; // Palavra-chave inicial
    this.searchMovies(defaultQuery);
  }

  searchMovies(query: string = this.searchQuery): void {
    if (!query.trim()) {
      this.errorMessage = 'Por favor, insira um título para buscar.';
      return;
    }

    this.omdbService.searchMovies(query, this.currentPage).subscribe({
      next: (response) => {
        if (response && response.Search) {
          this.movies = [];
          response.Search.forEach((movie: any) => {
            this.omdbService.getMovieDetails(movie.imdbID).subscribe({
              next: (details) => {
                this.movies.push(details);
              },
              error: (error) => {
                this.errorMessage = `Erro ao obter detalhes do filme: ${error}`;
              },
            });
          });
        } else {
          this.errorMessage = 'Nenhum filme encontrado.';
        }
      },
      error: (error) => {
        this.errorMessage = `Erro ao buscar filmes: ${error}`;
      },
    });
  }

  toggleFavorite(movie: Movie): void {
    if (this.favoritesService.isFavorite(movie.imdbID)) {
      this.favoritesService.removeFavorite(movie.imdbID);
    } else {
      this.favoritesService.addFavorite(movie);
    }
  }

  isFavorite(movieId: string): boolean {
    return this.favoritesService.isFavorite(movieId);
  }

  changePage(direction: number): void {
    if (this.currentPage + direction > 0) {
      this.currentPage += direction;
      this.searchMovies(); // Atualiza a busca para a nova página
    }
  }
}
